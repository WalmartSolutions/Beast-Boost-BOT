import uuid
import json
from datetime import datetime, timedelta
file_path = "keys/keys.json"
def load_keys_from_file(file_path):
    try:
        with open(file_path, "r") as file:
            keys = json.load(file)
    except (FileNotFoundError, json.decoder.JSONDecodeError):
        keys = []
    return keys

def save_keys_to_file(keys, file_path):
    with open(file_path, "w") as file:
        json.dump(keys, file, indent=4)

def generate_key(keys, month, amount, quantity, file_path):
    for _ in range(quantity):
        key = str(uuid.uuid4())
        key_data = {"key": key, "month": month, "amount": amount}
        keys.append(key_data)
    save_keys_to_file(keys, file_path)

def list_keys(keys):
    return keys

def delete_key(keys, key):
    for key_data in keys:
        if key_data["key"] == key:
            keys.remove(key_data)
    save_keys_to_file(keys, file_path)

def clear_file(file_path):
    keys = []
    save_keys_to_file(keys, file_path)

def menu():
    file_path = "keys/keys.json"
    while True:
        print("1. Generate Key")
        print("2. List Keys")
        print("3. Delete Key")
        print("4. Clear File")
        print("5. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            month = int(input("Enter month (1 or 3): "))
            amount = int(input("Enter amount: "))
            quantity = int(input("Enter quantity: "))
            keys = load_keys_from_file(file_path)
            generate_key(keys, month, amount, quantity, file_path)
        elif choice == "2":
            keys = load_keys_from_file(file_path)
            print("All Keys:", list_keys(keys))
        elif choice == "3":
            keys = load_keys_from_file(file_path)
            key_to_delete = input("Enter the key to delete: ")
            delete_key(keys, key_to_delete)
            print("Key deleted.")
        elif choice == "4":
            clear_file(file_path)
            print("File cleared.")
        elif choice == "5":
            print("Exiting program.")
            break
        else:
            print("Invalid choice. Please try again.")

