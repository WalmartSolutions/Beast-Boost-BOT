import discord
from discord.interactions import Interaction
from discord.ui import button
import json, httpx, tls_client, threading, time, random, hashlib, sys, os
from discord.ui.item import Item
from flask import request, Flask, jsonify
from discord.ui import Modal, TextInput
from discord.ext import commands
from discord import app_commands
from json.decoder import JSONDecodeError
import key_system
from licensing.models import *
from licensing.methods import Key, Helpers
import os
import logging
from pymongo import MongoClient


def create_folder_if_not_exists(folder_path):
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
        print(f"Folder '{folder_path}' created.")

def create_file_if_not_exists(file_path):
    if not os.path.exists(file_path):
        with open(file_path, 'w') as f:
            f.write('')
        print(f"File '{file_path}' created.")

def setup_folders_and_files():
    # Check and create 'keys' folder if it doesn't exist
    keys_folder_path = 'keys'
    create_folder_if_not_exists(keys_folder_path)
    
    # Check and create 'keys.json' if it doesn't exist
    keys_file_path = os.path.join(keys_folder_path, 'keys.json')
    create_file_if_not_exists(keys_file_path)
    
    # Check and create 'used_keys.json' if it doesn't exist
    used_keys_file_path = os.path.join(keys_folder_path, 'used_keys.json')
    create_file_if_not_exists(used_keys_file_path)
    
    # Check and create 'output' folder if it doesn't exist
    output_folder_path = 'output'
    create_folder_if_not_exists(output_folder_path)
    
    # Check and create 'success.txt' if it doesn't exist
    success_file_path = os.path.join(output_folder_path, 'success.txt')
    create_file_if_not_exists(success_file_path)
    
    # Check and create 'failed_boosts.txt' if it doesn't exist
    failed_boosts_file_path = os.path.join(output_folder_path, 'failed_boosts.txt')
    create_file_if_not_exists(failed_boosts_file_path)
    
    # Check and create 'data' folder if it doesn't exist
    data_folder_path = 'data'
    create_folder_if_not_exists(data_folder_path)
    
    # Check and create '1m.txt' if it doesn't exist
    one_million_file_path = os.path.join(data_folder_path, '1m.txt')
    create_file_if_not_exists(one_million_file_path)
    
    # Check and create '3m.txt' if it doesn't exist
    three_million_file_path = os.path.join(data_folder_path, '3m.txt')
    create_file_if_not_exists(three_million_file_path)

# Run the setup function
setup_folders_and_files()

def check_installed(module):
    try:
        __import__(module)
        return True
    except ImportError:
        return False
def main():
    # Run 'pip install -r requirements.txt' command
    try:
        os.system('pip install -r requirements.txt')
        print("All required modules are installed. Proceeding further.")
    except Exception as e:
        print(f"An error occurred: {e}")
        print("Failed to install required modules. Please check the error message.")

if __name__ == "__main__":
    main()

bot = commands.Bot( command_prefix=",", intents=discord.Intents.all())

# tree = commands.CommandTree(bot)

# Define colors and styles
class Fore:
    BLACK = "\033[30m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"
    UNDERLINE = "\033[4m"
    RESET = "\033[0m"

# Define the log format with colors and styles
log_format = f'{Fore.GREEN}[%(levelname)s]{Fore.RESET} %(asctime)s - %(message)s'
logging.basicConfig(level=logging.INFO, format=log_format)

powerboosts = f"""{Fore.GREEN}

██████╗░░█████╗░░█████╗░░██████╗████████╗  ██████╗░░█████╗░████████╗
██╔══██╗██╔══██╗██╔══██╗██╔════╝╚══██╔══╝  ██╔══██╗██╔══██╗╚══██╔══╝
██████╦╝██║░░██║██║░░██║╚█████╗░░░░██║░░░  ██████╦╝██║░░██║░░░██║░░░
██╔══██╗██║░░██║██║░░██║░╚═══██╗░░░██║░░░  ██╔══██╗██║░░██║░░░██║░░░
██████╦╝╚█████╔╝╚█████╔╝██████╔╝░░░██║░░░  ██████╦╝╚█████╔╝░░░██║░░░
╚═════╝░░╚════╝░░╚════╝░╚═════╝░░░░╚═╝░░░  ╚═════╝░░╚════╝░░░░╚═╝░░░
{Fore.RESET}"""

# Define colors for the gradient
gradient_colors = [Fore.RED, Fore.YELLOW, Fore.GREEN, Fore.CYAN, Fore.BLUE, Fore.MAGENTA]

# Function to animate the gradient
def animate_gradient():
    for i in range(len(gradient_colors) * 2):
        os.system('cls' if os.name == 'nt' else 'clear')  # Clear the console
        for line in powerboosts.split('\n'):
            gradient_index = i % len(gradient_colors)
            print(f"{gradient_colors[gradient_index]}{line}{Fore.RESET}")
        time.sleep(0.1)

# Animate the gradient
animate_gradient()

t1 = f"""{Fore.YELLOW}➤ ONLY BUY THE BOOST BOT FROM OUR SHOP [ {Fore.BLUE}https://king.sellauth.com{Fore.YELLOW} ]{Fore.RESET}"""

# Print the powerboosts and text
# print(powerboosts)
print(t1)

logging.info("Cracked by WalmartSolutions - github.com/WalmartSolutions")
logging.info("BEAST BOOST BOT is ready! [ Powered By Power Boosts ] | Thanks for using")


app = Flask(__name__)

def getchecksum():
    md5_hash = hashlib.md5()
    file = open(''.join(sys.argv), "rb")
    md5_hash.update(file.read())
    digest = md5_hash.hexdigest()
    return digest



config = json.load(open("config.json", encoding="utf-8"))

class Booster:
    def __init__(self) -> None:
        self.proxy = self.getProxy()
        self.getCookies()
        self.client = tls_client.Session(
            client_identifier="chrome_107",
            ja3_string="771,4866-4867-4865-49196-49200-49195-49199-52393-52392-49327-49325-49188-49192-49162-49172-163-159-49315-49311-162-158-49314-49310-107-106-103-64-57-56-51-50-157-156-52394-49326-49324-49187-49191-49161-49171-49313-49309-49233-49312-49308-49232-61-192-60-186-53-132-47-65-49239-49235-49238-49234-196-195-190-189-136-135-69-68-255,0-11-10-35-16-22-23-49-13-43-45-51-21,29-23-30-25-24,0-1-2",
            h2_settings={
                "HEADER_TABLE_SIZE": 65536,
                "MAX_CONCURRENT_STREAMS": 1000,
                "INITIAL_WINDOW_SIZE": 6291456,
                "MAX_HEADER_LIST_SIZE": 262144,
            },
            h2_settings_order=[
                "HEADER_TABLE_SIZE",
                "MAX_CONCURRENT_STREAMS",
                "INITIAL_WINDOW_SIZE",
                "MAX_HEADER_LIST_SIZE",
            ],
            supported_signature_algorithms=[
                "ECDSAWithP256AndSHA256",
                "PSSWithSHA256",
                "PKCS1WithSHA256",
                "ECDSAWithP384AndSHA384",
                "PSSWithSHA384",
                "PKCS1WithSHA384",
                "PSSWithSHA512",
                "PKCS1WithSHA512",
            ],
            supported_versions=["GREASE", "1.3", "1.2"],
            key_share_curves=["GREASE", "X25519"],
            cert_compression_algo="brotli",
            pseudo_header_order=[":method", ":authority", ":scheme", ":path"],
            connection_flow=15663105,
            header_order=["accept", "user-agent", "accept-encoding", "accept-language"],
        )
        self.failed = []
        self.success = []
        self.captcha = []
        if config["proxyless"] == False:
            self.client.proxies = self.proxy

    def getProxy(self):
        try:
            proxy = random.choice(open("data/proxies.txt", "r").read().splitlines())
            return {"http": f"http://{proxy}", "https": f"http://{proxy}"}
        except Exception as e:
            pass

    def getCookies(self, session=None):
        headers = {
            "accept": "*/*",
            "accept-language": "en-US,en;q=0.5",
            "connection": "keep-alive",
            "host": "canary.discord.com",
            "referer": "https://canary.discord.com/",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "user-agent": "Mozilla/5.0 (Macintosh; U; PPC Mac OS X; de-de) AppleWebKit/85.8.5 (KHTML, like Gecko) Safari/85",
            "x-context-properties": "eyJsb2NhdGlvbiI6IkFjY2VwdCBJbnZpdGUgUGFnZSJ9",
            "x-debug-options": "bugReporterEnabled",
            "x-discord-locale": "en-US",
            "x-super-properties": "eyJvcyI6Ik1hYyBPUyBYIiwiYnJvd3NlciI6IlNhZmFyaSIsImRldmljZSI6IiIsInN5c3RlbV9sb2NhbGUiOiJlbi1KTSIsImJyb3dzZXJfdXNlcl9hZ2VudCI6Ik1vemlsbGEvNS4wIChNYWNpbnRvc2g7IFU7IFBQQyBNYWMgT1MgWDsgZGUtZGUpIEFwcGxlV2ViS2l0Lzg1LjguNSAoS0hUTUwsIGxpa2UgR2Vja28pIFNhZmFyaS84NSIsImJyb3dzZXJfdmVyc2lvbiI6IiIsIm9zX3ZlcnNpb24iOiIiLCJyZWZlcnJlciI6IiIsInJlZmVycmluZ19kb21haW4iOiIiLCJyZWZlcnJlcl9jdXJyZW50IjoiIiwicmVmZXJyaW5nX2RvbWFpbl9jdXJyZW50IjoiIiwicmVsZWFzZV9jaGFubmVsIjoic3RhYmxlIiwiY2xpZW50X2J1aWxkX251bWJlciI6MTgxODMyLCJjbGllbnRfZXZlbnRfc291cmNlIjoibnVsbCJ9",
        }
        response = httpx.get(
            "https://canary.discord.com/api/v9/experiments", headers=headers
        )
        self.dcfduid = response.cookies.get("__dcfduid")
        self.sdcfduid = response.cookies.get("__sdcfduid")
        self.cfruid = response.cookies.get("__cfruid")

    def boost(self, token, invite, guild):
        headers = {
            "authority": "discord.com",
            "accept": "*/*",
            "accept-language": "fr-FR,fr;q=0.9",
            "authorization": token,
            "cache-control": "no-cache",
            "content-type": "application/json",
            "cookie": f"__dcfduid={self.dcfduid}; __sdcfduid={self.sdcfduid}; __cfruid={self.cfruid}; locale=en-US",
            "origin": "https://discord.com",
            "pragma": "no-cache",
            "referer": "https://discord.com/channels/@me",
            "sec-ch-ua": '"Google Chrome";v="107", "Chromium";v="107", "Not=A?Brand";v="24"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "user-agent": "Mozilla/5.0 (Macintosh; U; PPC Mac OS X; de-de) AppleWebKit/85.8.5 (KHTML, like Gecko) Safari/85",
            "x-debug-options": "bugReporterEnabled",
            "x-discord-locale": "en-US",
            "x-super-properties": "eyJvcyI6Ik1hYyBPUyBYIiwiYnJvd3NlciI6IlNhZmFyaSIsImRldmljZSI6IiIsInN5c3RlbV9sb2NhbGUiOiJlbi1KTSIsImJyb3dzZXJfdXNlcl9hZ2VudCI6Ik1vemlsbGEvNS4wIChNYWNpbnRvc2g7IFU7IFBQQyBNYWMgT1MgWDsgZGUtZGUpIEFwcGxlV2ViS2l0Lzg1LjguNSAoS0hUTUwsIGxpa2UgR2Vja28pIFNhZmFyaS84NSIsImJyb3dzZXJfdmVyc2lvbiI6IiIsIm9zX3ZlcnNpb24iOiIiLCJyZWZlcnJlciI6IiIsInJlZmVycmluZ19kb21haW4iOiIiLCJyZWZlcnJlcl9jdXJyZW50IjoiIiwicmVmZXJyaW5nX2RvbWFpbl9jdXJyZW50IjoiIiwicmVsZWFzZV9jaGFubmVsIjoic3RhYmxlIiwiY2xpZW50X2J1aWxkX251bWJlciI6MTgxODMyLCJjbGllbnRfZXZlbnRfc291cmNlIjoibnVsbCJ9",
        }

        slots = httpx.get(
            "https://discord.com/api/v9/users/@me/guilds/premium/subscription-slots",
            headers=headers,
        )

        slot_json = slots.json()

        if slots.status_code == 401:
            self.failed.append(token)
            return

        if slots.status_code != 200 or len(slot_json) == 0:
            return

        r = self.client.post(
            f"https://discord.com/api/v9/invites/{invite}", headers=headers, json={}
        )

        if r.status_code == 200:
            boostsList = []
            for boost in slot_json:
                boostsList.append(boost["id"])

            payload = {"user_premium_guild_subscription_slot_ids": boostsList}

            headers["method"] = "PUT"
            headers["path"] = f"/api/v9/guilds/{guild}/premium/subscriptions"

            boosted = self.client.put(
                f"https://discord.com/api/v9/guilds/{guild}/premium/subscriptions",
                json=payload,
                headers=headers,
            )

            if boosted.status_code == 201:
              self.success.append(token)
              with open("output/success.txt", "a") as file:
                file.write(token + "\n")
                self.success.append(token)
                return True
            else:
             with open("output/failed_boosts.txt", "a") as file:
                file.write(token + "\n")
             self.failed.append(token)


        elif r.status_code == 400:
          with open("output/failed_boosts.txt", "a") as file:
            file.write(token + "\n")
          self.failed.append(token)

        elif r.status_code != 200:
            print(r.json())

    def nick(self, token, guild, nick):
        headers = {
            "authority": "discord.com",
            "accept": "*/*",
            "accept-language": "fr-FR,fr;q=0.9",
            "authorization": token,
            "cache-control": "no-cache",
            "content-type": "application/json",
            "cookie": f"__dcfduid={self.dcfduid}; __sdcfduid={self.sdcfduid}; __cfruid={self.cfruid}; locale=en-US",
            "origin": "https://discord.com",
            "pragma": "no-cache",
            "referer": "https://discord.com/channels/@me",
            "sec-ch-ua": '"Google Chrome";v="107", "Chromium";v="107", "Not=A?Brand";v="24"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "user-agent": "Mozilla/5.0 (Macintosh; U; PPC Mac OS X; de-de) AppleWebKit/85.8.5 (KHTML, like Gecko) Safari/85",
            "x-debug-options": "bugReporterEnabled",
            "x-discord-locale": "en-US",
            "x-super-properties": "eyJvcyI6Ik1hYyBPUyBYIiwiYnJvd3NlciI6IlNhZmFyaSIsImRldmljZSI6IiIsInN5c3RlbV9sb2NhbGUiOiJlbi1KTSIsImJyb3dzZXJfdXNlcl9hZ2VudCI6Ik1vemlsbGEvNS4wIChNYWNpbnRvc2g7IFU7IFBQQyBNYWMgT1MgWDsgZGUtZGUpIEFwcGxlV2ViS2l0Lzg1LjguNSAoS0hUTUwsIGxpa2UgR2Vja28pIFNhZmFyaS84NSIsImJyb3dzZXJfdmVyc2lvbiI6IiIsIm9zX3ZlcnNpb24iOiIiLCJyZWZlcnJlciI6IiIsInJlZmVycmluZ19kb21haW4iOiIiLCJyZWZlcnJlcl9jdXJyZW50IjoiIiwicmVmZXJyaW5nX2RvbWFpbl9jdXJyZW50IjoiIiwicmVsZWFzZV9jaGFubmVsIjoic3RhYmxlIiwiY2xpZW50X2J1aWxkX251bWJlciI6MTgxODMyLCJjbGllbnRfZXZlbnRfc291cmNlIjoibnVsbCJ9",
        }

        payload = {"nick": nick}

        httpx.patch(
            f"https://discord.com/api/v9/guilds/{guild}/members/@me",
            headers=headers,
            json=payload,
        )

        httpx.patch(
            f"https://discord.com/api/v9/users/@me/profile",
            headers=headers,
            json={"bio": nick},
        )

    def nickThread(self, tokens, guild, nick):
        """"""
        threads = []

        for i in range(len(tokens)):
            token = tokens[i]
            t = threading.Thread(target=self.nick, args=(token, guild, nick))
            t.daemon = True
            threads.append(t)

        for i in range(len(tokens)):
            threads[i].start()

        for i in range(len(tokens)):
            threads[i].join()

        return True

    def thread(self, invite, tokens, guild):
        """"""
        threads = []

        for i in range(len(tokens)):
            token = tokens[i]
            t = threading.Thread(target=self.boost, args=(token, invite, guild))
            t.daemon = True
            threads.append(t)

        for i in range(len(tokens)):
            threads[i].start()

        for i in range(len(tokens)):
            threads[i].join()
        
        return {
            "success": self.success,
            "failed": self.failed,
            "captcha": self.captcha,
        }
        





def getStock(filename: str):
    tokens = []
    for i in open(filename, "r").read().splitlines():
        if ":" in i:
            i = i.split(":")[2]
            tokens.append(i)
        else:
            tokens.append(i)
    return tokens


def getinviteCode(inv):
    if "discord.gg" not in inv:
        return inv
    if "discord.gg" in inv:
        invite = inv.split("discord.gg/")[1]
        return invite
    if "https://discord.gg" in inv:
        invite = inv.split("https://discord.gg/")[1]
        return invite
    if 'discord.com/invite' in inv:
        invite = inv.split("discord.com/invite/")[1]
    if 'https://discord.com/invite' in inv:
        invite = inv.split("https://discord.com/invite/")[1]


def checkInvite(invite: str):
    data = httpx.get(
        f"https://discord.com/api/v9/invites/{invite}?inputValue={invite}&with_counts=true&with_expiration=true"
    ).json()

    if data["code"] == 10006:
        return False
    elif data:
        return data["guild"]["id"]
    else:
        return False


class BoostModal(Modal):
    def __init__(self):
        super().__init__(title = "Boost")
        self.add_item(
            TextInput(
                label = "Invite",
                placeholder = "Invite code of the server.",
                required = True,
                style = discord.TextStyle.short
            )
        )

        self.add_item(
            TextInput(
                label = "Amount",
                placeholder = "Amount of boosts (must be in numbers).",
                required = True,
                style = discord.TextStyle.short
            )
        )

        self.add_item(
            TextInput(
                label = "Months",
                placeholder = "Number of months (1/3).",
                required = True,
                style = discord.TextStyle.short
            )
        )

        self.add_item(
            TextInput(
                label = "Nick",
                placeholder = "Nickname and bio.",
                required = True,
                style = discord.TextStyle.short
            )
        )
    
    async def on_submit(self, ctx: discord.Interaction):

        invite = self.children[0].value

        amount = int(self.children[1].value)

        months = int(self.children[2].value)

        nick = self.children[3].value

        await ctx.response.defer()

        if amount % 2 != 0:
            return await ctx.followup.send(
                embed=discord.Embed(
                    title="**ERROR**",
                    description="❎ | Number of boosts should be in numbers.",
                    color=0x2F3136,
                )
            )

        if months != 1 and months != 3:
            return await ctx.followup.send(
                embed=discord.Embed(
                    title="**ERROR**",
                    description="❎ | Invalid months [VALID INPUTS: 1/3].",
                    color=0x2F3136,
                )
            )

        inviteCode = getinviteCode(invite)
        inviteData = checkInvite(inviteCode)

        if inviteData == False:
            return await ctx.followup.send(
                embed=discord.Embed(
                    title="**ERROR**",
                    description="❎ | Invalid invite provided.",
                    color=0x2F3136,
                )
            )

        if months == 1:
            filename = "data/1m.txt"
        if months == 3:
            filename = "data/3m.txt"

        tokensStock = getStock(filename)
        requiredStock = int(amount / 2)

        if requiredStock > len(tokensStock):
            return await ctx.followup.send(
                embed=discord.Embed(
                    title="**ERROR**",
                    description=f"❎ | We don't have enough tokens in stock\nUse `/restock` command to restock.",
                    color=0x2F3136,
                )
            )

        boost = Booster()

        tokens = []

        for x in range(requiredStock):
            tokens.append(tokensStock[x])
            remove(tokensStock[x], filename)

        await ctx.followup.send(
            embed=discord.Embed(
                title="Boost Bot", description=f"Boosting....", color=0x2F3136
            )
        )

        start = time.time()
        status = boost.thread(inviteCode, tokens, inviteData)
        time_taken = round(time.time() - start, 2)

        await ctx.followup.send(
            embed=discord.Embed(
                title="**Boosts Successful**",
                description=f"**__Amount__ ->**  {amount} boosts \n**__Months__ ->** {months}m \n**__Server Link__ ->** .gg/{inviteCode} \n**__Tokens__ ->** {requiredStock} \n**__Success__ ->** {len(status['success'])} \n**__Failed__ ->** {len(status['failed'])}\n**__Time taken__ ->** {time_taken}s",
                color=0x2F3136,
            )
        )

        boost.nickThread(tokens, inviteData, nick)


@bot.event
async def on_ready():
    await bot.change_presence(status=discord.Status.dnd, activity=discord.Activity(type=discord.ActivityType.listening, name='Best Boost Bot'))
    print(f"{Fore.BLUE} [BOT]: {bot.user} is online.{Fore.RESET}")
    try:        
        await bot.tree.sync()

        print(f'Synced')
    except Exception as e:
        print(e)



@bot.tree.command(
    name="boost", description="Boost a server by using that command."
)
async def boost(
    ctx: discord.Interaction
):
    
    if str(ctx.user.id) not in config["owners_ids"]:
     member = ctx.guild.get_member(ctx.user.id)
     if str(ctx.user.id) not in config["owners_ids"] and not any(str(role.id) in config["admin_role_ids"] for role in member.roles):
        
        return await ctx.response.send_message(
            embed=discord.Embed(
                title="**ERROR**",
                description="❎ | Missing permissions, you cannot use this command.",
                color=0x2F3136,
            )
        )
    
    modal = BoostModal()
    await ctx.response.send_modal(modal)
    # await ctx.response.defer(ephemeral=False)


def remove(token: str, filename: str):
    tokens = getStock(filename)
    tokens.pop(tokens.index(token))
    f = open(filename, "w")

    for x in tokens:
        f.write(f"{x}\n")

    f.close()


class PanelView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
    

    @button(label = "1", custom_id="panelboost")

    async def panel_boost(self, interaction, button):
      member = interaction.guild.get_member(interaction.user.id)
      if str(interaction.user.id) in config["owners_ids"] or any(str(role.id) in config["admin_role_ids"] for role in member.roles):

        await interaction.response.send_modal(BoostModal())
      else:
          await interaction.response.send_message("Unauthorised", ephemeral=True)
    
    @button(label= "2", custom_id="panelstock")
    async def panel_stock(self,interaction,button):
      member = interaction.guild.get_member(interaction.user.id)
      if str(interaction.user.id) in config["owners_ids"] or any(str(role.id) in config["admin_role_ids"] for role in member.roles):

        await interaction.response.send_modal(StockModal())
      else:
          await interaction.response.send_message("Unauthorised", ephemeral=True)
    
    @button(label = "3", custom_id="panelrestock")
    async def panel_restock(self, interaction, button):
      member = interaction.guild.get_member(interaction.user.id)
      if str(interaction.user.id) in config["owners_ids"] or any(str(role.id) in config["admin_role_ids"] for role in member.roles):

        await interaction.response.send_modal(RestockModal())
      else:
          await interaction.response.send_message("Unauthorised", ephemeral=True)
    
    @button(label = "4", custom_id="panelgivetoken")
    async def panel_givetoken(self, interaction, button):
      member = interaction.guild.get_member(interaction.user.id)
      if str(interaction.user.id) in config["owners_ids"] or any(str(role.id) in config["admin_role_ids"] for role in member.roles):

                await interaction.response.send_modal(SendtokensModal())
      else:
          await interaction.response.send_message("Unauthorised", ephemeral=True)



class AutoView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
    

    @button(label="1", custom_id="autoboost")
    async def panel_boost(self, interaction, button):
        await interaction.response.send_modal(Auto_Boost_Modal())
    @button(label="2", custom_id="check_key_information")
    async def check_key(self, interaction, button):
        await interaction.response.send_modal(Check_Key_Modal())
    @button(label="3", custom_id="check_stock")
    async def stock(self, interaction, button):
        await interaction.response.send_modal(StockModal())    
    @button(label="4", custom_id="auto_guide")
    async def guide(self, interaction, button):
        await interaction.response.send_message(embed=discord.Embed(
            title="__AutoBoosting Guide__",
            description="**Facts & Questions** \n 1. How to use the auto boosting? \n -> Click on the 1 button and a model/form will appear where you have to enter key, invite of server & nickname and bio for the tokens! \n 2. What if the boosts get failed? \n -> Thanks to the advanced key system! If the boosts gets failed then for example you have a key with 14 boosts as balance and if some boosts failed due to token issue then the total balance - successful will be deducted and other will be still present in the key and you can retry with the key again! \n 3. What if the bot didnt have stock? \n -> Create a support ticket and contact the management!",
            color=0x2F3136,
            
        ), ephemeral = True)     

@bot.tree.command(
   name="panel", description="Shows the boost bot panel."
)
async def panel(
    ctx
):  
    embed = discord.Embed(
        title = "Boost Bot Panel"
    ).add_field(
        name = "Available Options: ",
        value = "1 - Boost Server\n 2 - Check Current Stockn \n 3 - Restock Tokens By Text Content\n 4 - Give Tokens To a User Via Dmes"
    ).set_thumbnail(url = "https://media.discordapp.net/attachments/1169200145804578816/1169884553058455603/logo.jpg")
    member = ctx.guild.get_member(ctx.user.id)
    if str(ctx.user.id) in config["owners_ids"] or any(str(role.id) in config["admin_role_ids"] for role in member.roles):
        await ctx.response.send_message(embed = embed, view = PanelView())
    else: 
        await ctx.response.send_message('unauthorised')
class SendtokensModal(Modal):
    def __init__(self):
        super().__init__(title = "Send Tokens")

        self.add_item(
            TextInput(
                label = "Member ID",
                placeholder = "The member you want to send.",
                required = True,
                style = discord.TextStyle.short
            )
        )

        self.add_item(
            TextInput(
                label = "Amount",
                placeholder = "Amount of tokens to send.",
                required = True,
                style = discord.TextStyle.short
            )
        )

        self.add_item(
            TextInput(
                label = "Months",
                placeholder = "Number of months (1/3).",
                required = True,
                style = discord.TextStyle.short
            )
        )
    

    async def on_submit(self, ctx):



        member = ctx.guild.get_member(int(self.children[0].value))
        amount = int(self.children[1].value)
        months = int(self.children[2].value)


        await ctx.response.defer()

        if months != 1 and months != 3:
            return await ctx.followup.send(
                embed=discord.Embed(
                    title="**ERROR**",
                    description="❎ | Invalid months [VALID INPUTS: 1/3].",
                    color=0x2F3136,
                )
            )

        if months == 1:
            filename = "data/1m.txt"
        if months == 3:
            filename = "data/3m.txt"

        tokensStock = getStock(filename)

        if amount > len(tokensStock):
            return await ctx.followup.send(
                embed=discord.Embed(
                    title="**ERROR**",
                    description=f"❎ | We don't have enough tokens in stock\nUse `/restock` command to restock.",
                    color=0x2F3136,
                )
            )

        tokens = []
        for x in range(amount):
            tokens.append(tokensStock[x])
            remove(tokensStock[x], filename)

        stuff = "\n".join(tokens)

        with open("result.txt", "w") as file:
            file.write(stuff.format("\n", "\n"))

        with open("result.txt", mode="rb") as f:
            await member.send(
                embed=discord.Embed(
                    title="Boost Bot",
                    description=f"✅ | Thanks for using our services.",
                    color=0x2F3136,
                ),
                file=discord.File(f),
            )

        return await ctx.followup.send(
            embed=discord.Embed(
                title="Boost Bot",
                description=f"✅ | Sent {amount}x tokens.",
                color=0x2F3136,
            )
        )

@bot.tree.command(
name="sendtokens", description="Sends the tokens to the user."
)
async def sendtokens(
    ctx,
):

     member = ctx.guild.get_member(ctx.user.id)
     if str(ctx.user.id) in config["owners_ids"] or any(str(role.id) in config["admin_role_ids"] for role in member.roles):
        await ctx.response.send_modal(SendtokensModal())
     else:
         await ctx.response.send_message("unauthorised")
         




class MyView(discord.ui.View):
    @discord.ui.button(label="1", row=1, style=discord.ButtonStyle.grey, )
    async def first_button_callback(self, interaction, button):
        await interaction.response.send_message(embed=discord.Embed(
            title="__Management Commands__",
            description="**/boost** \n [ Refer to direct boost model which takes invite link, month, amount and nick & bio for boosting ] \n  **/restock** \n [ Takes txt file and type of tokens such as 1month or 3month and adds in the file! ] \n **/stock** \n [ Take which type of stock you wanna check ( 1 month ot 3 month ) and return that! ] \n **/sendtokens** \n [ Takes user developer id, type of tokens and amount and send that to user! ] \n **/panel** \n [ Show Admin Boost Panel ] \n **/addowner** \n [ Used to add owner [ owner should be a person not a role & admin is a role ] ( only owner can use it ) ]",
            color=0x2F3136,
        ))
    @discord.ui.button(label="2", row=1, style=discord.ButtonStyle.grey)
    async def second_button_callback(self, interaction, button):
        await interaction.response.send_message(embed=discord.Embed(
            title='__Public Commands__',
            description='**/get_key_information** \n [ Takes (key) and return information about the key such as month & boost amount it have! ] \n **/get_used_key_information** \n [ Takes (used_key) and return information about the key such as month, boost, successful boosts, failed boosts and time taken for boosting! ]',
            color=0x2F3136,
        ))
    @discord.ui.button(label="3", row=1, style=discord.ButtonStyle.grey)
    async def third_button_callback(self, interaction, button):
        await interaction.response.send_message(embed=discord.Embed(
            title='__AutoBoosting Commands__',
            description='**/get_key_information** \n [ Takes (key) and return information about the key such as month & boost amount it have! ] \n **/get_used_key_information** \n [ Takes (used_key) and return information about the key such as month, boost, successful boosts, failed boosts and time taken for boosting! ] \n **/make_keys** \n [ Used to make keys in database for autoboosting ( takes month, boost_amount for each key, quantity/number-of-keys-to-create ) ] \n **/get_all_keys** \n [ To get all keys in the json file in your dmes ] \n **/get_keys** \n [ Get keys with a specific requirements such as 1 month keys with 14 boosts and no of keys you need ( you will get in txt format and every new line represent a new key) ] \n **/get_key** \n [ Used to get a specific 1 key with month and amount required ] \n ** /delete_keys** \n [ To delete keys with specific requirements and only can be used to delete all keys! ] \n **/delete_key** \n [ Takes a key as an argument and delete that ]',
            color=0x2F3136,
        ))    

@bot.tree.command( name="help", description="It will show the help menu.")
async def help(ctx):
    await ctx.response.send_message(
        embed=discord.Embed(
            title="Help Menu",
            description="**Click on the buttons to start!** \n **Options** \n 1 - Management Only Commands \n 2 - Public Commands \n 3 - AutoBoosting Commands \n",
            color=0x2F3136
            ),
            view=MyView()
    )





@bot.tree.command(
 name="addowner", description="Add a member as a owner."
)
async def addowner(
    ctx,
    member: discord.Member
):
    if str(ctx.user.id) not in config["owners_ids"]:
        return await ctx.response.send_message(
            embed=discord.Embed(
                title="**ERROR**",
                description="❎ | You cannot use this command.",
                color=0x2F3136,
            )
        )

    config["owners_ids"].append(str(member.id))
    with open("config.json", "w") as f:
        json.dump(config, f, indent=4)
    c = ctx.channel
    return await c.send(
        embed=discord.Embed(
            title="Boost Bot",
            description=f"✅ | Added owner successfully",
            color=0x2F3136,
        )
    )

@bot.tree.command(
 name="addadmin_role", description="Add a member as a owner."
)
async def addadmin_role(
    ctx,
    role: discord.Role
):
    if str(ctx.user.id) not in config["owners_ids"]:
        return await ctx.response.send_message(
            embed=discord.Embed(
                title="**ERROR**",
                description="❎ | You cannot use this command.",
                color=0x2F3136,
            )
        )
    c = ctx.channel    
    config["admin_role_ids"].append(str(role.id))
    with open("config.json", "w") as f:
        json.dump(config, f, indent=4)

    return await c.send(
        embed=discord.Embed(
            title="Boost Bot",
            description=f"✅ | Added admin successfully",
            color=0x2F3136,
        )
    )


class StockModal(Modal):
    def __init__(self):
        super().__init__(title = "Stocks")

        self.add_item(
            TextInput(
                label = "Duration",
                placeholder = "Months? [1/3]",
                required = True,
                style = discord.TextStyle.short
            )
        )
    
    async def on_submit(self, ctx: Interaction):

        duration = int(self.children[0].value)
        
        await ctx.response.defer(ephemeral=False)

        if duration != 1 and duration != 3 and duration != 0:
            return await ctx.followup.send(
                embed=discord.Embed(
                    title="**ERROR**",
                    description="❎ | Invalid type. [1/3] are valid inputs.",
                    color=0x2F3136,
                ), ephemeral=True
            )

        if duration == 1:
            fileName = "data/1m.txt"
        elif duration == 3:
            fileName = "data/3m.txt"

        stock = len(open(fileName, "r").readlines())
        if len(open(fileName, "r").readlines()) == 0:
            stock = 0

        return await ctx.followup.send(
            embed=discord.Embed(
                title=f"**__{duration} months tokens__**",
                description=f"\n -> ``We have`` **{stock}** ``tokens and`` **{stock * 2}** ``boosts in stock``",
                color=0x2F3136,
            ), ephemeral=True
        )



@bot.tree.command(
 name="stock", description="Display the stock of boosts and tokens."
)
async def stock(
    ctx
): 
     member = ctx.guild.get_member(ctx.user.id)
     if str(ctx.user.id) in config["owners_ids"] or any(str(role.id) in config["admin_role_ids"] for role in member.roles): 
      await ctx.response.send_modal(StockModal())
     else:
         await ctx.response.send_message("unauthorised")
class RestockModal(Modal):
    def __init__(self):
        super().__init__(title = "Restock Tokens")

        self.add_item(
            TextInput(
                label = "Duration",
                placeholder = "Months? [1/3]",
                required = True,
                style = discord.TextStyle.short
            )
        )

        self.add_item(
            TextInput(
                label = "Tokens",
                placeholder = "Enter Tokens",
                required = True,
                style = discord.TextStyle.paragraph,
                max_length=4000
            )
        )
    
    async def on_submit(self, ctx: Interaction):
        
        duration = int(self.children[0].value)
        tokens = self.children[1].value.split("\n")

        if duration != 1 and duration != 3 and duration != 0:
            return await ctx.response.send_message(
                embed=discord.Embed(
                    title="**ERROR**",
                    description="❎ | Invalid duration. [1/3] are valid inputs.",
                    color=0x2F3136,
                )
            )
        
        if duration == 1:
            fileName = "data/1m.txt"
        elif duration == 3:
            fileName = "data/3m.txt"
        
        with open(fileName, "a") as f:
            for t in tokens:
                f.write(t+"\n")
        
        await ctx.followup.send(
            embed=discord.Embed(
                title="Boost Bot",
                description=f"✅ | Restocked successfully",
                color=0x2F3136,
            )
        )


@bot.tree.command(
 name="restock", description="Add the tokens in the stock."
)
async def restock(
    ctx,
    type: int,
    file: discord.Attachment
    ):
    # await ctx.defer(ephemeral=False)

    member = ctx.guild.get_member(ctx.user.id)
    if str(ctx.user.id) not in config["owners_ids"] and not any(str(role.id) in config["admin_role_ids"] for role in member.roles):
        return await ctx.response.send_message(
            embed=discord.Embed(
                title="**ERROR**",
                description="❎ | Missing permissions, you cannot use this command.",
                color=0x2F3136,
            )
        )

    if type != 1 and type != 3 and type != 0:
        return await ctx.response.send_message(
            embed=discord.Embed(
                title="**ERROR**",
                description="❎ | Invalid type. [1/3] are valid inputs.",
                color=0x2F3136,
            )
        )

    if type == 1:
        fileName = "data/1m.txt"
    elif type == 3:
        fileName = "data/3m.txt"

    content = await file.read()

    stuff = content.decode().split("\r\n")
    before = getStock(fileName)

    for x in range(len(before)):
        stuff.append(before[x])

    cute = "\n".join(stuff)
    text = cute.replace("b'", "").replace("'", "")

    with open(fileName, "w") as file:
        file.write(text + "\n")

    return await ctx.response.send_message(
        embed=discord.Embed(
            title="Boost Bot",
            description=f"✅ | Restocked successfully",
            color=0x2F3136,
        )
    )
@bot.tree.command(name='make_keys', description="Command to create key for key order system")
async def make_keys(ctx, month: int, boosts_amount: int, quantity: int):
    member = ctx.guild.get_member(ctx.user.id)
    if str(ctx.user.id) in config["owners_ids"] or any(str(role.id) in config["admin_role_ids"] for role in member.roles):
        embed = None
        if month not in [1, 3]:
            embed = discord.Embed(
                title="Boost Bot",
                description="⭕ | The month should be 1 or 3",
                color=0x2F3136,
            )
        elif boosts_amount % 2 != 0:
            embed = discord.Embed(
                title="Boost Bot",
                description="⭕ | The amount should be an even number",
                color=0x2F3136,
            )
        elif quantity > 100:
            embed = discord.Embed(
                title="Boost Bot",
                description="⭕ | The quantity can't be greater than 100!",
                color=0x2F3136,
            )
        else:
            keys = key_system.load_keys_from_file("keys/keys.json")
            key_system.generate_key(keys, month, boosts_amount, quantity, "keys/keys.json")
            embed = discord.Embed(
                title="Boost Bot",
                description=f"Successfully made {quantity} keys for {boosts_amount}x {month} month server boosts! Use `/get_keys` to fetch/download them",
                color=0x2F3136,
            )
    else:
        embed = discord.Embed(
            title="Boost Bot",
            description="⭕ | You are not authorized to use this command!",
            color=0x2F3136,
        )

    await ctx.response.send_message(embed=embed)

@bot.tree.command(name='get_all_keys', description="Command to get keys for key order system")
async def get_keys(ctx):
  member = ctx.guild.get_member(ctx.user.id)
  if str(ctx.user.id) in config["owners_ids"] or any(str(role.id) in config["admin_role_ids"] for role in member.roles):

    try:
        with open("keys/keys.json", "rb") as file:
            await ctx.user.send(file=discord.File(file, "keys.txt"))
            await ctx.response.send_message("Please, check your dmes and make sure it's open", ephemeral=True)
    except FileNotFoundError:
        await ctx.response.send_message("No keys found.")
  else:
      await ctx.response.send_message("unauthorised")


@bot.tree.command(name='get_keys', description="Command to get keys for key order system")
async def get_keys(ctx, month: int, amount: int, quantity: int):
  member = ctx.guild.get_member(ctx.user.id)
  if str(ctx.user.id) in config["owners_ids"] or any(str(role.id) in config["admin_role_ids"] for role in member.roles):
    try:
        with open("keys/keys.json", "r") as file:
            all_keys = json.load(file)
        
        filtered_keys = [key for key in all_keys if key['month'] == month and key['amount'] == amount]
        if len(filtered_keys) < quantity:
            await ctx.response.send_message("Not enough keys found for the specified criteria.")
            return
        
        keys_to_send = filtered_keys[:quantity]

        # Create a string containing all the keys separated by commas and new lines
        keys_str = '\n'.join(key['key'] for key in keys_to_send)

        with open("keys/filtered_keys.txt", "w") as file:
            file.write(f"{keys_str}")
        
        with open("keys/filtered_keys.txt", "rb") as file:
            await ctx.user.send(file=discord.File(file, "keys/filtered_keys.txt"))
        
        await ctx.response.send_message("Filtered keys sent to your DM.")
    except FileNotFoundError:
        await ctx.response.send_message("No keys found.")
  else:      
      await ctx.response.send_message("unauthorised.")

@bot.tree.command(name='delete_keys', description="Command to delete keys from the system")
async def delete_keys(ctx, month: int, amount: int, quantity: int, delete_all_keys: bool = False):
  member = ctx.guild.get_member(ctx.user.id)

  if str(ctx.user.id) in config["owners_ids"] or any(str(role.id) in config["admin_role_ids"] for role in member.roles):
    try:
        with open("keys/keys.json", "r") as file:
            all_keys = json.load(file)

        if delete_all_keys:
            all_keys = []
        else:
            filtered_keys = [key for key in all_keys if key['month'] == month and key['amount'] == amount]
            if len(filtered_keys) < quantity:
                await ctx.response.send_message("Not enough keys found for the specified criteria.")
                return
            all_keys = [key for key in all_keys if key not in filtered_keys]
        
        with open("keys/keys.json", "w") as file:
            json.dump(all_keys, file, indent=4)
        
        await ctx.response.send_message("Keys deleted successfully.")
    except FileNotFoundError:
      await ctx.response.send_message("No keys found.")
  else:
      await ctx.response.send_message("unauthorised")


import json

def mark_key_used(key, month, amount, invite, successful, failed, time_taken):
    # Load keys from the keys.json file
    with open("keys/keys.json", "r") as file:
        keys = json.load(file)

    # Remove the used key from the list of keys
    updated_keys = [k for k in keys if k['key'] != key]

    # Save the updated list of keys back to the keys.json file
    with open("keys/keys.json", "w") as file:
        json.dump(updated_keys, file, indent=4)

    # Load used keys from the used_keys.json file
    try:
        with open("keys/used_keys.json", "r") as file:
            used_keys = json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        used_keys = []

    # Append the used key along with additional information
    used_keys.append({
        "key": key,
        "month": month,
        "amount": amount,
        "invite": invite,
        "successful": successful,
        "failed" : failed,
        "time_taken" : time_taken
    })

    # Save the updated list of used keys back to the used_keys.json file
    with open("keys/used_keys.json", "w") as file:
        json.dump(used_keys, file, indent=4)
def fetch_from_key(key):
    with open("keys/keys.json", "r") as file:
        keys = json.load(file)
        for k in keys:
            if k['key'] == key:
                return k['amount'], k['month']
    raise KeyError

def check_key_used(key):
    with open("keys/used_keys.json", "r") as file:
        used_keys = json.load(file)
        return key in used_keys

def update_key(key, new_amount):
    with open('keys/keys.json', 'r+') as file:
        keys = json.load(file)
        for item in keys:
            if item['key'] == key:
                item['amount'] = new_amount
                file.seek(0)  # Move the cursor to the beginning of the file
                json.dump(keys, file, indent=4)
                file.truncate()  # Truncate the file to remove any remaining content
                break  # Exit the loop once the key is found and updated
        else:
            print(f"Key '{key}' not found in keys.json")

@bot.tree.command(
    name="auto_boosting",
    description="Shows the auto_boosting bot panel."
)
async def auto_panel(ctx, channel: discord.TextChannel = None):
    embed = discord.Embed(
        title="Auto Boosting Bot Panel",
        description="Available Options: "
    )
    embed.add_field(
        name="Options:",
        value="[ 1 ] Automated Server Boosting With Key\n [ 2 ] View Your Key Information\n [ 3 ] View Stock \n [ 4 ] Guide About Auto Boosting",
        inline=False
    ).color = 0x2F3136
    cv = ctx.channel
    member = ctx.guild.get_member(ctx.user.id)
    if str(ctx.user.id) in config["owners_ids"] or any(str(role.id) in config["admin_role_ids"] for role in member.roles):
        await ctx.response.send_message("Processing", ephemeral=True)
        if channel is None:
            await cv.send(embed=embed, view=AutoView())
        else:
            await channel.send(embed=embed, view=AutoView())
    else:
        await ctx.response.send_message("unauthorised", ephemeral=True)


class Check_Key_Modal(Modal):
    def __init__(self):
        super().__init__(title = "Boost")
        self.add_item(
            TextInput(
                label = "Key",
                placeholder = "Enter your key.",
                required = True,
                style = discord.TextStyle.short
            )
        )
    async def on_submit(self, ctx: discord.Interaction):   
        key = self.children[0].value
        try:
            with open("keys/keys.json", "r") as file:
                all_keys = json.load(file)
        
            key_info = next((k for k in all_keys if k['key'] == key), None)
            if key_info:
                embed=discord.Embed(
                        title="**Boost Bot**",
                        description=f"Key: {key_info['key']}\nMonth: {key_info['month']}\nAmount: {key_info['amount']}",
                    color=0x2F3136,
                )
                await ctx.response.send_message(embed=embed, ephemeral=True)
            else:
                await ctx.response.send_message("Key not found.", ephemeral=True)
        except FileNotFoundError:
            await ctx.response.send_message("No keys found.", ephemeral=True)
    
        

        

class Auto_Boost_Modal(Modal):
    def __init__(self):
        super().__init__(title = "Boost")
        self.add_item(
            TextInput(
                label = "Key",
                placeholder = "Enter your key.",
                required = True,
                style = discord.TextStyle.short
            )
        )
        self.add_item(
            TextInput(
                label = "Invite",
                placeholder = "Invite code of the server.",
                required = True,
                style = discord.TextStyle.short
            )
        )

        

        self.add_item(
            TextInput(
                label = "Nick",
                placeholder = "Nickname and bio.",
                required = False,
                style = discord.TextStyle.short
            )
        )
    
    async def on_submit(self, ctx: discord.Interaction):
        
        key = self.children[0].value
        invite_code = self.children[1].value
        nick = self.children[2].value
        

        try:
            amount, months = fetch_from_key(key)
        except KeyError:
            await ctx.response.send_message(
                embed=discord.Embed(
                    title="**ERROR**",
                    description="❎ | Invalid key or key not found.",
                    color=0x2F3136,
                ), ephemeral=True
            )
        await ctx.response.defer()

        if amount % 2 != 0:
            return await ctx.followup.send(
                embed=discord.Embed(
                    title="**ERROR**",
                    description="❎ | Number of boosts should be in numbers.",
                    color=0x2F3136,
                ), ephemeral=True
            )

        if months != 1 and months != 3:
            return await ctx.followup.send(
                embed=discord.Embed(
                    title="**ERROR**",
                    description="❎ | Invalid months [VALID INPUTS: 1/3].",
                    color=0x2F3136,
                ), ephemeral=True
            )

        inviteCode = getinviteCode(invite_code)
        inviteData = checkInvite(inviteCode)

        if inviteData == False:
            return await ctx.followup.send(
                embed=discord.Embed(
                    title="**ERROR**",
                    description="❎ | Invalid invite provided.",
                    color=0x2F3136,
                ), ephemeral=True
            )

        if months == 1:
            filename = "data/1m.txt"
        if months == 3:
            filename = "data/3m.txt"

        tokensStock = getStock(filename)
        requiredStock = int(amount / 2)

        if requiredStock > len(tokensStock):
            await ctx.followup.send(
                embed=discord.Embed(
                    title="**ERROR**",
                    description=f"❎ | We don't have enough tokens in stock\nUse `/restock` command to restock.",
                    color=0x2F3136,
                ), ephemeral=True
            )
        boost = Booster()

        tokens = []

        for x in range(requiredStock):
            tokens.append(tokensStock[x])
            remove(tokensStock[x], filename)

        await ctx.followup.send(
            embed=discord.Embed(
                title="Boost Bot", description=f"Boosting....", color=0x2F3136
            ), ephemeral=True
        )

        start = time.time()
        status = boost.thread(inviteCode, tokens, inviteData)

        time_taken = round(time.time() - start, 2)
        if len(status['failed']) > 0:
            embed = discord.Embed(
        title="Failed Boosts",
        description=f"Due to some issues there was some issues in the tokens such as captcha/invalid/flagged. No of failed boosts  {len(status['failed'])*2}. But don't worry your key balance is not reduced for failed boosts. You can retry with the same key with the existing balance. Sorry for the inconvenience caused. If you still face any type of issue make sure to contact the server management! \n Update Key Information -> \n **Balance** - {len(status['failed'])*2} Boosts \n", 
        color=0x2F3136
    )
            await ctx.followup.send(embed=embed, ephemeral=True)
            update_key(key, int(len(status["failed"]) * 2))
        else:   
            mark_key_used(key, months, amount, invite_code, len(status['success']), len(status['failed']), time_taken)



        


        await ctx.followup.send(
            embed=discord.Embed(
                title="**Boosts Successful**",
                description=f"**__Amount__ ->**  {amount} boosts \n**__Months__ ->** {months}m \n**__Server Link__ ->** .gg/{inviteCode} \n**__Tokens__ ->** {requiredStock} \n**__Success__ ->** {len(status['success'])} \n**__Failed__ ->** {len(status['failed'])}\n**__Time taken__ ->** {time_taken}s",
                color=0x2F3136,
            ), ephemeral=True
        )
        # if len(status['captcha']) != 0 or len(status["failed"]) != 0:
        #     await ctx.followup.send(
        #     embed=discord.Embed(
        #         title="**Note**",
        #         description=f"Out of {amount} boosts only {len(status['success'])} are done and {len(status['failed'])}\n**__Captcha tokens__ ->** {len(status['captcha'])} \n**__Time taken__ ->** {time_taken}s. Please make a support ticket!\n",
        #         color=0x5598D2,
        #     )
        # )

        boost.nickThread(tokens, inviteData, nick)

@bot.tree.command(name='get_key_information', description="Command to get information about a specific key")
async def get_key_information(ctx, key: str):
    try:
        with open("keys/keys.json", "r") as file:
            all_keys = json.load(file)
        
        key_info = next((k for k in all_keys if k['key'] == key), None)
        if key_info:
            embed=discord.Embed(
                    title="**Boost Bot**",
                    description=f"Key: {key_info['key']}\nMonth: {key_info['month']}\nAmount: {key_info['amount']}",
                    color=0x2F3136,
                )
            await ctx.response.send_message(embed=embed)
        else:
            await ctx.response.send_message("Key not found.")
    except FileNotFoundError:
        await ctx.response.send_message("No keys found.")
@bot.tree.command(name='key_stats', description="Command to show statistics about keys")
async def key_stats(ctx):
    try:
        with open("keys/keys.json", "r") as file:
            all_keys = json.load(file)

        one_month_keys = sum(1 for key in all_keys if key['month'] == 1)
        three_month_keys = sum(1 for key in all_keys if key['month'] == 3)

        amount_stats = {}
        amount_stats_with_months = {}

        for key in all_keys:
            amount = key['amount']
            if amount in amount_stats:
                amount_stats[amount] += 1
            else:
                amount_stats[amount] = 1

            if amount in amount_stats_with_months:
                amount_stats_with_months[amount]['total'] += 1
                if key['month'] == 1:
                    amount_stats_with_months[amount]['1m'] += 1
                elif key['month'] == 3:
                    amount_stats_with_months[amount]['3m'] += 1
            else:
                amount_stats_with_months[amount] = {'total': 1, '1m': 0, '3m': 0}
                if key['month'] == 1:
                    amount_stats_with_months[amount]['1m'] += 1
                elif key['month'] == 3:
                    amount_stats_with_months[amount]['3m'] += 1

        stats_message = f"1 Month Keys: {one_month_keys}\n3 Month Keys: {three_month_keys}\n\nAmount Statistics:\n"
        for amount, count in amount_stats.items():
            stats_message += f"{amount} amount keys: {count} (1m: {amount_stats_with_months[amount]['1m']}, 3m: {amount_stats_with_months[amount]['3m']})\n"
            embed=discord.Embed(
                    title="**Boost Bot**",
                    description=stats_message,
                    color=0x2F3136,
                )
        await ctx.response.send_message(embed=embed)
    except FileNotFoundError:
        await ctx.response.send_message("No keys found.")

@bot.tree.command(name='get_used_key_information', description="Command to get information about a specific used key")
async def get_used_key_information(ctx, key: str):
    try:
        with open("keys/used_keys.json", "r") as file:
            all_keys = json.load(file)
        
        key_info = next((k for k in all_keys if k['key'] == key), None)
        if key_info:
            embed=discord.Embed(
                    title="**Boost Bot**",
                    description=f"Key: {key_info['key']}\nMonth: {key_info['month']}\nAmount: {key_info['amount']} \n Successful: {key_info['successful']} \n Failed: {key_info['failed']} \n Time-Taken: {key_info['time_taken']}s \n Invite: {key_info['invite']}",
                    color=0x2F3136,
                )
            
            await ctx.response.send_message(embed=embed)
        else:
            await ctx.response.send_message("Key not found.")
    except FileNotFoundError:
        await ctx.response.send_message("No keys found.")
import discord

@bot.tree.command(name='get_key', description="Command to get keys for key order system")
async def get_key(ctx, month: int, amount: int):
  member = ctx.guild.get_member(ctx.user.id)
  if str(ctx.user.id) in config["owners_ids"] or any(str(role.id) in config["admin_role_ids"] for role in member.roles):
    try:
        with open("keys/keys.json", "r") as file:
            all_keys = json.load(file)
        
        filtered_keys = [key for key in all_keys if key['month'] == month and key['amount'] == amount]
        if not filtered_keys:
            await ctx.response.send_message("No keys found for the specified criteria.")
            return
        
        key_to_send = filtered_keys[0]  # Get the first key matching the criteria

        embed = discord.Embed(title="Filtered Key", color=0x2F3136)
        embed.add_field(name="Month", value=key_to_send['month'], inline=False)
        embed.add_field(name="Amount", value=key_to_send['amount'], inline=False)
        embed.add_field(name="Key", value=key_to_send['key'], inline=False)
        
        await ctx.response.send_message(embed=embed)
    except FileNotFoundError:
              await ctx.response.send_message("No keys found.")
  else:
      await ctx.response.send_message("Unauthorised")

@bot.tree.command(name='delete_key', description="Command to delete a specific key from the system")
async def delete_key(ctx, key_to_delete: str):
    member = ctx.guild.get_member(ctx.user.id)

    if str(ctx.user.id) in config["owners_ids"] or any(str(role.id) in config["admin_role_ids"] for role in member.roles):
        try:
            with open("keys/keys.json", "r") as file:
                all_keys = json.load(file)

            filtered_keys = [key for key in all_keys if key['key'] == key_to_delete]
            if not filtered_keys:
                await ctx.response.send_message("Key not found.")
                return

            all_keys = [key for key in all_keys if key not in filtered_keys]

            with open("keys/keys.json", "w") as file:
                json.dump(all_keys, file, indent=4)
            embed = discord.Embed(title="Key Deleted!" , description=f"{key_to_delete} successfully deleted", color=0x2F3136)
            await ctx.response.send_message(embed=embed)
        except FileNotFoundError:
            await ctx.response.send_message("No keys found.")
    else:
        await ctx.response.send_message("Unauthorized")
@bot.tree.command(name='get_failed_tokens', description="Command to get failed tokens and send them to DMs")
async def get_failed_tokens(ctx):
    member = ctx.guild.get_member(ctx.user.id)
    if str(ctx.user.id) in config["owners_ids"] or any(str(role.id) in config["admin_role_ids"] for role in member.roles):
        try:
            with open("output/failed_boosts.txt", "r") as file:
                failed_tokens = file.read()
                
            # Sending failed tokens to user's DM
            await ctx.user.send(failed_tokens)
            
            # Sending success message in embed
            embed = discord.Embed(
                title="Success",
                description="Failed tokens successfully sent to your DMs.",
                color=0x2F3136
            )
        except Exception as e:
            embed = discord.Embed(
                title="Error",
                description=f"An error occurred: {str(e)}",
                color=0xFF0000
            )
    else:
        embed = discord.Embed(
            title="Unauthorized",
            description="You are not authorized to use this command.",
            color=0xFF0000
        )

    await ctx.response.send_message(embed=embed)

    bot.run(config["token"])